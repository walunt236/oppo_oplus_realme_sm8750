// SPDX-License-Identifier: GPL-2.0
#include <kunit/test.h>
#include "../zero.h"

static void memcomp_zero_is_page_test(struct kunit *test)
{
	u8 *page = kunit_kzalloc(test, PAGE_SIZE, GFP_KERNEL);

	KUNIT_ASSERT_NOT_NULL(test, page);
	KUNIT_EXPECT_TRUE(test, mc16_zero_is_page(page, PAGE_SIZE));
	page[0] = 1;
	KUNIT_EXPECT_FALSE(test, mc16_zero_is_page(page, PAGE_SIZE));
	page[0] = 0;
	page[PAGE_SIZE - 1] = 1;
	KUNIT_EXPECT_FALSE(test, mc16_zero_is_page(page, PAGE_SIZE));
	KUNIT_EXPECT_FALSE(test, mc16_zero_is_page(NULL, PAGE_SIZE));
	KUNIT_EXPECT_FALSE(test, mc16_zero_is_page(page, PAGE_SIZE - 1));
}

static void memcomp_zero_nr_test(struct kunit *test)
{
	KUNIT_EXPECT_TRUE(test, mc16_zero_nr_valid(0));
	KUNIT_EXPECT_TRUE(test, mc16_zero_nr_valid((unsigned long)LONG_MAX));
	KUNIT_EXPECT_FALSE(test, mc16_zero_nr_valid(~0UL));
}

static void memcomp_zero_stat_test(struct kunit *test)
{
	unsigned long compressed = 123;
	int mapcount = -1;

	KUNIT_EXPECT_FALSE(test, mc16_zero_entry_stat(1, &compressed, &mapcount));
	KUNIT_EXPECT_TRUE(test, mc16_zero_entry_stat(0, NULL, NULL));
	KUNIT_EXPECT_TRUE(test, mc16_zero_entry_stat(0, &compressed, &mapcount));
	KUNIT_EXPECT_EQ(test, compressed, 0UL);
	KUNIT_EXPECT_EQ(test, mapcount, 1);
}

static struct kunit_case memcomp_zero_cases[] = {
	KUNIT_CASE(memcomp_zero_is_page_test),
	KUNIT_CASE(memcomp_zero_nr_test),
	KUNIT_CASE(memcomp_zero_stat_test),
	{}
};

static struct kunit_suite memcomp_zero_suite = {
	.name = "memcomp-zero",
	.test_cases = memcomp_zero_cases,
};

kunit_test_suite(memcomp_zero_suite);
MODULE_LICENSE("GPL");
