// SPDX-License-Identifier: GPL-2.0
#include <kunit/test.h>
#include "../format.h"

static void memcomp_format_flags_test(struct kunit *test)
{
	u16 flags = 0;

	KUNIT_EXPECT_TRUE(test, mc16_flags_encode(MC16_STORED, 2,
						  MC16_F_OWNER |
						  MC16_F_RESIDENT, &flags));
	KUNIT_EXPECT_EQ(test, mc16_flags_state(flags), MC16_STORED);
	KUNIT_EXPECT_EQ(test, mc16_flags_order(flags), 2);
	KUNIT_EXPECT_TRUE(test, flags & MC16_F_OWNER);
	KUNIT_EXPECT_TRUE(test, flags & MC16_F_RESIDENT);
	KUNIT_EXPECT_TRUE(test, mc16_flags_valid(flags));

	KUNIT_EXPECT_FALSE(test, mc16_flags_encode(MC16_SAMEFILL + 1, 0, 0,
						   &flags));
	KUNIT_EXPECT_FALSE(test, mc16_flags_encode(MC16_EMPTY,
						   MC16_MAX_ORDER + 1, 0,
						   &flags));
	KUNIT_EXPECT_FALSE(test, mc16_flags_encode(MC16_EMPTY, 0,
						   MC16_RESERVED_MASK,
						   &flags));
	KUNIT_EXPECT_FALSE(test, mc16_flags_valid(MC16_F_OWNER |
						  MC16_RESERVED_MASK));
}

static void memcomp_format_length_test(struct kunit *test)
{
	u16 encoded = 0;
	u32 bytes = 0;

	KUNIT_EXPECT_TRUE(test, mc16_length_encode(1, &encoded));
	KUNIT_EXPECT_EQ(test, encoded, 0);
	KUNIT_EXPECT_TRUE(test, mc16_length_decode(encoded, &bytes));
	KUNIT_EXPECT_EQ(test, bytes, 1);

	KUNIT_EXPECT_TRUE(test, mc16_length_encode(PAGE_SIZE, &encoded));
	KUNIT_EXPECT_TRUE(test, mc16_length_decode(encoded, &bytes));
	KUNIT_EXPECT_EQ(test, bytes, PAGE_SIZE);

	KUNIT_EXPECT_FALSE(test, mc16_length_encode(0, &encoded));
	KUNIT_EXPECT_FALSE(test, mc16_length_encode(PAGE_SIZE + 1, &encoded));
	KUNIT_EXPECT_FALSE(test, mc16_length_decode(PAGE_SIZE, &bytes));
}

static void memcomp_format_payload_test(struct kunit *test)
{
	u16 encoded = 0;
	u32 bytes = 0;

	KUNIT_EXPECT_TRUE(test, mc16_payload_length_encode(MC16_STORED,
							   123, &encoded));
	KUNIT_EXPECT_TRUE(test, mc16_payload_length_decode(MC16_STORED,
							   encoded, &bytes));
	KUNIT_EXPECT_EQ(test, bytes, 123);

	KUNIT_EXPECT_TRUE(test, mc16_payload_length_encode(MC16_SAMEFILL,
							   0, &encoded));
	KUNIT_EXPECT_EQ(test, encoded, 0);
	KUNIT_EXPECT_TRUE(test, mc16_payload_length_decode(MC16_SAMEFILL,
							   encoded, &bytes));
	KUNIT_EXPECT_EQ(test, bytes, 0);

	KUNIT_EXPECT_FALSE(test, mc16_payload_length_encode(MC16_SAMEFILL,
							    1, &encoded));
	KUNIT_EXPECT_FALSE(test, mc16_payload_length_encode(MC16_EMPTY,
							    1, &encoded));
}

static void memcomp_format_swap_test(struct kunit *test)
{
	u64 word = 0;
	u16 length = 0;
	struct mc16_swap_fields fields;

	KUNIT_EXPECT_TRUE(test, mc16_swap_encode(1, 42, 0, PAGE_SIZE, false,
						 &word, &length));
	KUNIT_EXPECT_TRUE(test, mc16_swap_decode(word, length, &fields));
	KUNIT_EXPECT_EQ(test, fields.type, 1);
	KUNIT_EXPECT_EQ(test, fields.swap_offset, 42);
	KUNIT_EXPECT_EQ(test, fields.byte_offset, 0);
	KUNIT_EXPECT_EQ(test, fields.length, PAGE_SIZE);
	KUNIT_EXPECT_FALSE(test, fields.packed);

	KUNIT_EXPECT_TRUE(test, mc16_swap_encode(1, 42, 7, 100, true,
						 &word, &length));
	KUNIT_EXPECT_TRUE(test, mc16_swap_decode(word, length, &fields));
	KUNIT_EXPECT_EQ(test, fields.byte_offset, 7);
	KUNIT_EXPECT_EQ(test, fields.length, 100);
	KUNIT_EXPECT_TRUE(test, fields.packed);

	KUNIT_EXPECT_FALSE(test, mc16_swap_encode(32, 0, 0, 1, false,
						 &word, &length));
	KUNIT_EXPECT_FALSE(test, mc16_swap_encode(1, 0, 7, 1, false,
						 &word, &length));
	KUNIT_EXPECT_FALSE(test, mc16_swap_encode(1, 0, PAGE_SIZE - 1, 2, true,
						 &word, &length));
}

static struct kunit_case memcomp_format_cases[] = {
	KUNIT_CASE(memcomp_format_flags_test),
	KUNIT_CASE(memcomp_format_length_test),
	KUNIT_CASE(memcomp_format_payload_test),
	KUNIT_CASE(memcomp_format_swap_test),
	{}
};

static struct kunit_suite memcomp_format_suite = {
	.name = "memcomp-format",
	.test_cases = memcomp_format_cases,
};

kunit_test_suite(memcomp_format_suite);
MODULE_LICENSE("GPL");
